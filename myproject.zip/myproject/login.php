<?php
session_start();
if(isset($_SESSION['uid']))
{
	header('location:admin/admindash.php');
}



?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
</head>
<body>
	
      <h1 style="text-align: center;">Admin Login</h1>
      <h3><a href="index.php" style="float: left;" >Home</a></h3>

    <table align="center">
       	<form action="login.php" method="post">
       		<tr>
       			<td>Enter Username</td><td><input type="text" name="uname"></td>
       		</tr>
       		<tr>
       			<td>Enter Password</td><td><input type="password" name="pass"></td>
       		</tr>
       		<tr>
       			<td><input type="submit" name="login" value="login"></td>
       		</tr>

       	</form>
    </table>
</body>
</html>
<?php
include('dbconn.php');
if(isset($_POST['login']))
{
	$Username = $_POST['uname'];
	$password = $_POST['pass'];

	$qry = "SELECT * FROM `admin` WHERE `username`='$Username' AND `password`='$password'";

	$run=mysqli_query($con,$qry);
	$row=mysqli_num_rows($run);
	if($row<1)
	{
		?>
		<script>
			alert('Username or Password not match !!!');
		</script>
		<?php
	}
	else
	{
		$data=mysqli_fetch_assoc($run); 
		$id=$data['id'];
		session_start();
		$_SESSION['uid']=$id;
		header('location:admin/admindash.php');
	}
}
?>
  

