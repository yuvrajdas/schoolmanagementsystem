<?php
session_start();
if(isset($_SESSION['uid']))
{
	echo "";
}
else
{
	header('locaton: ../login.php');
}

?>
<?php
include('header.php');
include('titlehead.php')
?>
<form method="post" action="addstudent.php" enctype="multipart/form-data">
	<table align="center" border="1px" style=" margin-top: 70px;">
	
		<tr>
			<td>Roll No.</td>
			<td><input type="text" name="rollno" required="required" placeholder="Enter Roll No." style="width: 99%"></td>
		</tr>

		<tr>
			<td>Full Name</td>
			<td><input type="text" name="name" required="required" placeholder="Enter Full Name" style="width: 99%"></td>
		</tr>

		<tr>
			<td>City</td>
			<td><input type="text" name="city" required="required" placeholder="Enter City" style="width: 99%"></td>
		</tr>

		<tr>
			<td>Parents Contact No.</td>
			<td><input type="text" name="pcon" required="required" placeholder="Enter Parents Contact No." style="width: 99%">
			</td>
		</tr>

		<tr>
			<td>Standerd</td>
			<td><input type="text" name="std" required="required" placeholder="Enter Standerd" style="width: 99%"></td>
		</tr>

		<tr>
			<td>Browse Image</td>
			<td><input type="file" name="simg" required="required"></td>
		</tr>

		<tr>
			<td colspan="2" align="center"><input type="submit" name="submit"></td>
		</tr>
	</table>
</form> 

<?php

if(isset($_POST['submit']))
{
	include('../dbconn.php');
	$rollno=$_POST['rollno'];
	$name=$_POST['name'];
	$city=$_POST['city'];
	$pcon=$_POST['pcon'];
	$std=$_POST['std'];
	$imagename = $_FILES['simg']['name'];
	$tempname = $_FILES['simg']['tmp_name'];
	move_uploaded_file($tempname, "../dataimg/$imagename");

	$qry = "INSERT INTO `student`(`rollno`, `name`, `city`, `pcon`, `standerd`,`image`) VALUES ('$rollno','$name','$city','$pcon','$std','$imagename')";
	$run=mysqli_query($con,$qry);
	if($run==true)
	{
		?>
		<script>
			alert('Data inserted successfully....');
		</script>
		<?php
	}


}

?>

	
