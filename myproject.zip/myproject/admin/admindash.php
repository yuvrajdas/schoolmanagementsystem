<?php
session_start();
if(isset($_SESSION['uid']))
{
	echo "";
}
else
{
	header('locaton: ../login.php');
}

?>
<?php
include('header.php');
?> 
<div class="admintitle">
	 <h3><a href="logout.php" style="float: right; margin-right: 30px; margin-top: 30px; font-size: 20px; color: #F5FBFB;" >Logout</a></h3>
	 <h3><a href="../index.php" style="float: left; margin-right: 30px; margin-top: 30px; font-size: 20px; color: #F5FBFB;" >Home</a></h3>
  <h1 >WELCOME TO ADMIN DASHBOARD</h1>


</div>
	<div class="dashboard">
		<table align="center" style="font-size: 20px;">
			<tr>
				<td>1.</td><td><a href="addstudent.php">Insert Student Details</a></td>
			</tr>

			<tr>
				<td>2.</td><td><a href="updatestudent.php">Update Student Details</a></td>
			</tr>

			<tr>
				<td>3.</td><td><a href="deletestudent.php">Delete Student Details</a></td>
			</tr>
			</a>
		</table>
		
	</div>
</body>
</html>