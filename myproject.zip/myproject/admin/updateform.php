<?php
session_start();
if(isset($_SESSION['uid']))
{
	echo "";
}
else
{
	header('locaton: ../login.php');
}

?>
<?php
include('header.php');
include('titlehead.php');
include('../dbconn.php');
$sid = $_GET['sid'];
$sql="SELECT * FROM `student` WHERE `id`='$sid'";
$run=mysqli_query($con,$sql);
$data = mysqli_fetch_assoc($run);
?>

<form method="post" action="updatedata.php" enctype="multipart/form-data">
	<table align="center" border="1px" style=" margin-top: 70px;">
	
		<tr>
			<td>Roll No.</td>
			<td><input type="text" name="rollno" value="<?php echo $data['rollno']; ?>" required="required" style="width: 99%"></td>
		</tr>

		<tr>
			<td>Full Name</td>
			<td><input type="text" name="name" required="required" value="<?php echo $data['name']; ?>" style="width: 99%"></td>
		</tr>

		<tr>
			<td>City</td>
			<td><input type="text" name="city" required="required" value="<?php echo $data['city']; ?>" style="width: 99%"></td>
		</tr>

		<tr>
			<td>Parents Contact No.</td>
			<td><input type="text" name="pcon" required="required" value="<?php echo $data['pcon']; ?>" style="width: 99%">
			</td>
		</tr>

		<tr>
			<td>Standerd</td>
			<td><input type="text" name="std" required="required" value="<?php echo $data['standerd']; ?>" style="width: 99%"></td>
		</tr>

		<tr>
			<td>Browse Image</td>
			<td><input type="file" name="simg" required="required"></td>
		</tr>

		<tr>
			<td colspan="2" align="center">
				<input type="hidden" name="sid" value="<?php echo $data['id']; ?>">
				<input type="submit" name="submit">
			</td>
		</tr>
	</table>
</form>