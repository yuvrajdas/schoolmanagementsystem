<div class="admintitle">
	 <h3><a href="logout.php" style="float: right; margin-right: 30px; margin-top: 30px; font-size: 20px; color: #F5FBFB;" >Logout</a></h3>
  <h1 >WELCOME TO ADMIN DASHBOARD</h1>
</div>