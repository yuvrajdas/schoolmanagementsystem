<?php
session_start();
if(isset($_SESSION['uid']))
{
	echo "";
}
else
{
	header('locaton: ../login.php');
}

?>
<?php
include('header.php');
include('titlehead.php')
?>
<table align="center" style="margin-top: 20px;">
	<form action="updatestudent.php" method="post">
		<tr>
			<td>Enter Standerd</td>
			<td><input type="number" name="standerd" required="required" placeholder="Enter Standerd"></td>
		
			<td>Enter Student Name</td>
			<td><input type="text" name="stuname" required="required" placeholder="Enter Student Name"></td>
		
			<td>
				<input type="submit" name="submit" value="Search">
			</td>
		</tr>
		
	</form>
</table>
<table align="center" border="1px" width="80%" style="margin-top: 20px;">
	<tr>
		<td>No.</td>
		<td>Image</td>
		<td>Name</td>
		<td>RollNo</td>
		<td>Edit</td>
	</tr>

	<?php
if(isset($_POST['submit']))
{
	include('../dbconn.php');
	$standerd=$_POST['standerd'];
	$name=$_POST['stuname'];

	$sql="SELECT * FROM `student` WHERE `standerd`='$standerd' AND `name` LIKE '%$name%'";
	$run=mysqli_query($con,$sql);
	if(mysqli_num_rows($run)<1)
	{
		echo "<tr><td colspan='5'>No Records Found</td></tr>";
	}
	else
	{	
		$count=0;
		while($data= mysqli_fetch_assoc($run))
		{
			$count++;
			?>
			<tr>
		        <td><?php echo $count; ?></td>
		        <td style="height: 80px; width: 150px;" ><img src="../dataimg/<?php echo $data['image'];?>" style="max-height: 150px; max-width: 200px;"></td>
		        <td><?php echo $data['name']; ?></td>
		        <td><?php echo $data['rollno']; ?></td>
		        <td><a href="updateform.php?sid=<?php echo $data['id']; ?>"> Edit</a></td>
	        </tr>
	        <?php

		}
	}

}

?>
</table>










