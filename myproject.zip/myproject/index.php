<!DOCTYPE html>
<html>
<head>
	<title>Student Management System</title>
    <style type="text/css">
        
        blink, .blink{
                     animation:blinker 1s linear infinite;
                     }
    @keyframes blinker {
    
    50%{  opacity: 0;}

    }
    .wrapper{
      position: relative;
    }
    video{
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      width: 100%;
    }
    </style>
</head>

<body background="images/Central-College-of-Engineering-and-Management-Raipur.jpg" style="background-repeat: no-repeat; background-size: cover; height: 100vh; " >
  

    <div class="wrappe">
<vide autoplay="autoplay" muted="muted" loop="infinite">
  <source src="afterscho.mp4" type="video/mp4">
  </video>
     
      <h3 style="text-align: right; margin-top: 50px; margin-right: 50px; color: white;"><a href="login.php"> Admin login</a></h3>
      
  	<h1 style="text-align: center; color: #1DCE64;"><blink>Welcome to Student Management System</blink></h1>
     

    <table align="center" border="1px;" width="30%" bgcolor="skyblue" >
    	<form action="" method="post">
    		<tr>
    			<th colspan="2" align="center">Student Information</th>
    		</tr>
    		<tr>
    			<td>Choose Standerd</td><td><select name="std" required="required" style="width: 100%">
    				<option value="1">1st</option>
    				<option value="2">2nd</option>
    				<option value="3">3rd</option>
    				<option value="4">4th</option>
    				<option value="5">5th</option>
    				<option value="6">6th</option>
    				<option value="7">7th</option>
    				<option value="8">8th</option>
                    <option value="9">9th</option>
                    <option value="10">10th</option>
                    <option value="11">11th</option>
                    <option value="12">12th</option>
    			</select></td>
    		</tr>
    		<tr>
    			<td width="100%">Enter RollNo.</td><td><input type="text" name="rollno" placeholder="Enter rollno" required="required"></td>
    		</tr>

    		<tr>
    			<td colspan="2" align="center"><input type="submit" name="submit" value="Show Information"></td>
    		</tr>
    	</form>
    </table>
</div>
</body>
</html>

<?php
if(isset($_POST['submit']))
{
   $standerd = $_POST['std'];
   $rollno = $_POST['rollno'];

   include('dbconn.php');
   include('function.php');

   showdetails($standerd,$rollno);


}

?>