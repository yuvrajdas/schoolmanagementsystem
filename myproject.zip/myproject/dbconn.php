<?php

$con=mysqli_connect('localhost','root','','sms');

if ($conn=false) {
	echo "Error...! Connection faild";
}

?>